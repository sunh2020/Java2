package com.sunh.zookeeper1;

public class GorillaTest {
	public static void main(String[] args) {
		Gorilla g = new Gorilla(0);
		g.throwSomething().throwSomething().throwSomething();
		g.eatBananas().eatBananas();
		g.climb();
		g.displayEnergy();
		
	}

}

		
