
public class Project {
	public Project() {
		
	}

	private String name;
	private String description;

	public Project(String name) {
		this.name = name;
	}

	public Project(String name, String description) {
		this.name = name;
		this.description = description;
	}
	
	public void setName (String name) {
		this.name = name;
	}
	public void setDescription (String description) {
		this.description = description;
	}
	public void elevatorPitch () {
		System.out.println(this.name + this.description);
		
	}
}
